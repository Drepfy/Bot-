#version 330

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

float parabolicMixFactor(float level) {
    return (2.0 * level - 1.0) * (2.0 * level - 1.0);
}

// ---- Diamond SMP coloured lighting ------------------------------------------
// Torch, lantern, fire and lava light: amber when dim, warm white up close.
vec3 dsl_torch(float b) {
    float t = clamp(b, 0.0, 1.0);
    return 1.06 * b * vec3(1.0, 0.58 + 0.32 * t, 0.22 + 0.50 * t);
}

// Sky light. Vanilla fades it from white (day) to #7a7aff (night); x is how far through
// that fade we are (1 = day, 0 = night), read from the colour itself so rain and
// thunder (which only grey it) do not count as dusk.
vec3 dsl_sky_light(vec3 sky) {
    float ratio = sky.r / max(sky.b, 1e-4);
    float x = clamp((ratio - 0.4784) / 0.5216, 0.0, 1.0);
    float twilight = 4.0 * x * (1.0 - x);
    vec3 tint = mix(vec3(0.8000, 1.0600, 1.0000), vec3(1.0), x);
    tint *= mix(vec3(1.0), vec3(1.2500, 0.9500, 0.6200), 0.80 * twilight);
    return sky * tint;
}

// The dimension's ambient light, recoloured at the same brightness: red-orange in the
// Nether, violet in the End. `nether` and `end` say which dimension this is.
vec3 dsl_haze(vec3 ambient, bool nether, bool end) {
    float lum = dot(ambient, vec3(0.2126, 0.7152, 0.0722));
    if (nether) return lum * vec3(1.5089, 0.8845, 0.6452);
    if (end) return lum * vec3(1.1218, 0.9023, 1.6095);
    return ambient;
}
// -----------------------------------------------------------------------------

void main() {
    // Calculate block and sky brightness levels based on texture coordinates
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    float block_brightness = get_brightness(block_level) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(sky_level) * lightmapInfo.SkyFactor;

    // Calculate ambient color with or without night vision
    vec3 nightVisionColor = lightmapInfo.NightVisionColor * lightmapInfo.NightVisionFactor;
    vec3 dslAmbient = lightmapInfo.AmbientColor;
    bool dslLit = max(dslAmbient.r, max(dslAmbient.g, dslAmbient.b)) > 0.08;
    vec3 color = max(dsl_haze(dslAmbient, dslLit && dslAmbient.r > 1.15 * dslAmbient.b,
        dslLit && dslAmbient.r <= 1.15 * dslAmbient.b), nightVisionColor);

    // Add sky light
    color += dsl_sky_light(lightmapInfo.SkyLightColor) * sky_brightness;

    // Add block light
    color += dsl_torch(block_brightness);

    // Apply boss overlay darkening effect
    color = mix(color, color * vec3(0.7, 0.6, 0.6), lightmapInfo.BossOverlayWorldDarkeningFactor);

    // Apply darkness effect scale
    color = color - vec3(lightmapInfo.DarknessScale);

    // Apply brightness
    color = clamp(color, 0.0, 1.0);
    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, lightmapInfo.BrightnessFactor);

    // Diamond SMP light boost: slight in bright light, stronger the darker it
    // gets. Fades out under the Darkness effect.
    {
        float boostLum = max(color.r, max(color.g, color.b));
        float boostDark = 1.0 - clamp(boostLum, 0.0, 1.0);
        float boostLift = 0.02 + 0.13 * boostDark * boostDark;
        boostLift *= 1.0 - clamp(lightmapInfo.DarknessScale * 4.0, 0.0, 1.0);
        color = color + (vec3(1.0) - color) * boostLift;
    }

    fragColor = vec4(color, 1.0);
}
