#version 330

layout(std140) uniform LightmapInfo {
    float AmbientLightFactor;
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float DarkenWorldFactor;
    float BrightnessFactor;
    vec3 SkyLightColor;
    vec3 AmbientColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float level) {
    return level / (4.0 - 3.0 * level);
}

vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

// ---- Diamond SMP coloured lighting ------------------------------------------
// Torch, lantern, fire and lava light: amber when dim, warm white up close.
vec3 dsl_torch(float b) {
    float t = clamp(b, 0.0, 1.0);
    return 1.06 * b * vec3(1.0, 0.58 + 0.32 * t, 0.22 + 0.50 * t);
}

// Sky light. Vanilla fades it from white (day) to #7a7aff (night); x is how far through
// that fade we are (1 = day, 0 = night), read from the colour itself so rain and
// thunder (which only grey it) do not count as dusk.
vec3 dsl_sky_light(vec3 sky) {
    float ratio = sky.r / max(sky.b, 1e-4);
    float x = clamp((ratio - 0.4784) / 0.5216, 0.0, 1.0);
    float twilight = 4.0 * x * (1.0 - x);
    vec3 tint = mix(vec3(0.8000, 1.0600, 1.0000), vec3(1.0), x);
    tint *= mix(vec3(1.0), vec3(1.2500, 0.9500, 0.6200), 0.80 * twilight);
    return sky * tint;
}

// The dimension's ambient light, recoloured at the same brightness: red-orange in the
// Nether, violet in the End. `nether` and `end` say which dimension this is.
vec3 dsl_haze(vec3 ambient, bool nether, bool end) {
    float lum = dot(ambient, vec3(0.2126, 0.7152, 0.0722));
    if (nether) return lum * vec3(1.5089, 0.8845, 0.6452);
    if (end) return lum * vec3(1.1218, 0.9023, 1.6095);
    return ambient;
}
// -----------------------------------------------------------------------------

void main() {
    float block_brightness = get_brightness(floor(texCoord.x * 16) / 15) * lightmapInfo.BlockFactor;
    float sky_brightness = get_brightness(floor(texCoord.y * 16) / 15) * lightmapInfo.SkyFactor;

    // cubic nonsense, dips to yellowish in the middle, white when fully saturated
    vec3 color = dsl_torch(block_brightness);

    color = mix(color, dsl_haze(lightmapInfo.AmbientColor,
        lightmapInfo.AmbientLightFactor > 0.05 && lightmapInfo.AmbientLightFactor < 0.175,
        lightmapInfo.AmbientLightFactor >= 0.175), lightmapInfo.AmbientLightFactor);

    color += dsl_sky_light(lightmapInfo.SkyLightColor) * sky_brightness;
    color = mix(color, vec3(0.75), 0.04);

    if (lightmapInfo.AmbientLightFactor == 0.0f) {
        vec3 darkened_color = color * vec3(0.7, 0.6, 0.6);
        color = mix(color, darkened_color, lightmapInfo.DarkenWorldFactor);
    }

    if (lightmapInfo.NightVisionFactor > 0.0) {
        // scale up uniformly until 1.0 is hit by one of the colors
        float max_component = max(color.r, max(color.g, color.b));
        if (max_component < 1.0) {
            vec3 bright_color = color / max_component;
            color = mix(color, bright_color, lightmapInfo.NightVisionFactor);
        }
    }

    if (lightmapInfo.AmbientLightFactor == 0.0f) {
        color = color - vec3(lightmapInfo.DarknessScale);
    }

    color = clamp(color, 0.0, 1.0);

    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, lightmapInfo.BrightnessFactor);
    color = mix(color, vec3(0.75), 0.04);

    // Diamond SMP light boost: slight in bright light, stronger the darker it
    // gets. Fades out under the Darkness effect.
    {
        float boostLum = max(color.r, max(color.g, color.b));
        float boostDark = 1.0 - clamp(boostLum, 0.0, 1.0);
        float boostLift = 0.02 + 0.13 * boostDark * boostDark;
        boostLift *= 1.0 - clamp(lightmapInfo.DarknessScale * 4.0, 0.0, 1.0);
        color = color + (vec3(1.0) - color) * boostLift;
    }

    fragColor = vec4(color, 1.0);
}
