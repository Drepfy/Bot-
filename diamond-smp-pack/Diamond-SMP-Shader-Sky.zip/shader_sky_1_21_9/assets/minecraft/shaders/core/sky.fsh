#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:diamond_blackhole.glsl>

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec3 skyPos;

out vec4 fragColor;

void main() {
    vec4 sky = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
    // Thick fog (water, lava, powder snow) hides the hole; ordinary distance fog does not.
    float clear = smoothstep(0.2, 0.8, 1.0 - 16.0 * FogColor.a / max(FogSkyEnd, 0.001));
    vec3 color = mix(sky.rgb, dbh_sky(sky.rgb, normalize(skyPos), dbh_time(GameTime)), clear);
    fragColor = vec4(color, sky.a);
}
