#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:diamond_starfield.glsl>

in vec3 Position;

out vec3 skyDir;
out float skyTrust;

void main() {
    // Vanilla draws ~1500 small star squares with this shader. Diamond SMP turns the first two
    // into one full-screen layer (opposite windings, so exactly one survives culling) and
    // collapses the rest; the fragment shader then paints the real night sky.
    int id = gl_VertexID;
    if (id >= 8) {
        gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
        skyDir = Position;
        skyTrust = 0.0;
        return;
    }
    int corner = id & 3;
    vec2 c = vec2(corner == 1 || corner == 2 ? 1.0 : -1.0, corner >= 2 ? 1.0 : -1.0);
    if (id >= 4) {
        c = c.yx;
    }
    gl_Position = vec4(c, 0.99999, 1.0);
    skyDir = dsf_world_ray(mat3(ModelViewMat), ProjMat, c, skyTrust);
}
