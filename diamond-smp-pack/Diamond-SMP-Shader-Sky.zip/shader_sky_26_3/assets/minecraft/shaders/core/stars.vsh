#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:diamond_starfield.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out vec3 skyDir;
layout(location = 1) out float skyTrust;

void main() {
    // Vanilla draws ~1500 small star squares with this shader. Diamond SMP turns the first two
    // into one full-screen layer (opposite windings, so exactly one survives culling) and
    // collapses the rest; the fragment shader then paints the real night sky.
    int id = gl_VertexIndex;
    if (id >= 8) {
        gl_Position = vec4(0.0, 0.0, 2.0, 1.0);
        skyDir = Position;
        skyTrust = 0.0;
        return;
    }
    int corner = id & 3;
    vec2 c = vec2(corner == 1 || corner == 2 ? 1.0 : -1.0, corner >= 2 ? 1.0 : -1.0);
    if (id >= 4) {
        c = c.yx;
    }
    gl_Position = vec4(c, 0.99999, 1.0);
    skyDir = dsf_world_ray(mat3(ModelViewMat), ProjMat, c, skyTrust);
}
