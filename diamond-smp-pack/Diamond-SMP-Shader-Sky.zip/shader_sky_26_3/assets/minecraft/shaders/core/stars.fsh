#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:diamond_starfield.glsl>

layout(location = 0) in vec3 skyDir;
layout(location = 1) in float skyTrust;

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 dir = normalize(skyDir);
    float px = 0.5 * (length(dFdx(dir)) + length(dFdy(dir)));   // angular size of a pixel
    if (!gl_FrontFacing) {
        discard;
    }
    // ColorModulator.a is vanilla's star brightness: 0 by day and in rain, 0.5 on a clear night.
    vec3 color = dsf_night_sky(dir, px, dsf_time(GameTime));
    fragColor = vec4(color * (clamp(2.0 * ColorModulator.a, 0.0, 1.0) * skyTrust), 1.0);
}
