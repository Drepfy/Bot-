#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:diamond_blackhole.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 sky = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
    // Thick fog (water, lava, powder snow) hides the hole; ordinary distance fog does not.
    float clear = smoothstep(0.2, 0.8, 1.0 - 16.0 * FogColor.a / max(FogSkyEnd, 0.001));
    vec3 color = mix(sky.rgb, dbh_sky(sky.rgb, normalize(skyPos), dbh_time(GameTime)), clear);
    fragColor = vec4(color, sky.a);
}
